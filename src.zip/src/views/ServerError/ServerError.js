import React from 'react';
import Main from 'layouts/Main';
import Container from 'components/Container';

const ServerError = () => {
  return (
    <Main>
      <Container>ServerError</Container>
    </Main>
  );
};

export default ServerError;
