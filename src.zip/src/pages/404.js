import React from 'react';
import NotFound from 'views/NotFound';

const FourOFourPage = () => {
  return <NotFound />;
};

export default FourOFourPage;
