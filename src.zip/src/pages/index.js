import React from 'react';
import Home from 'views/Home';

const HomePage = () => {
  return <Home />;
};

export default HomePage;
