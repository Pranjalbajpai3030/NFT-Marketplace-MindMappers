export { default } from './FeaturedNfts';
