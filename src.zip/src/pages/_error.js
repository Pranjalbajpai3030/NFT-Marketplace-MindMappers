import React from 'react';
import ServerError from 'views/ServerError';

const ErrorPage = () => {
  return <ServerError />;
};

export default ErrorPage;
